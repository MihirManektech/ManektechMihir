﻿using JetDevsAPI.DBClass;
using JetDevsAPI.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.Data;
using System.IdentityModel.Tokens.Jwt;
using System.Text;

namespace JetDevsAPI.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public UserController(IConfiguration configuration)
        {
            _configuration = configuration;
        }



        [HttpPost(Name = "UserLogin")]
        public UserModel UserLogin(string Email, string Password)
        {
            UserModel user = new UserModel();
            DBData dBData = new DBData();
            try
            {

                DataTable Dt = dBData.UserLogin(Email, Password);
                if (Dt.Rows.Count > 0)
                {
                    var tokenString = GenerateJSONWebToken(user);
                    user.token = tokenString;
                    user.FirstName = Dt.Rows[0]["FirstName"].ToString();
                    user.LastName = Dt.Rows[0]["LastName"].ToString();
                    user.Email = Dt.Rows[0]["Email"].ToString();
                    user.UserId = Convert.ToInt32(Dt.Rows[0]["UserId"].ToString());
                    user.status = "200";
                    user.message = "success";
                }
                else
                {
                    user.status = "300";
                    user.message = "Not Ok";
                }
            }
            catch (Exception ex)
            {
                user.status = "400";
                user.message = "Error" + ex.Message;

            }
            return user;
        }

        private string GenerateJSONWebToken(UserModel userInfo)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(_configuration["Jwt:Issuer"],
              _configuration["Jwt:Issuer"],
              null,
              expires: DateTime.Now.AddMinutes(120),
              signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }


        [HttpPost(Name = "UserByEmail")]
        [Authorize]
        public UserModel UserByEmail(string Email)
        {
            UserModel user = new UserModel();
            DBData dBData = new DBData();
            try
            {

                DataTable Dt = dBData.UserByEmail(Email);
                if (Dt.Rows.Count > 0)
                {
                  
                    user.FirstName = Dt.Rows[0]["FirstName"].ToString();
                    user.LastName = Dt.Rows[0]["LastName"].ToString();
                    user.Email = Dt.Rows[0]["Email"].ToString();
                    user.UserId = Convert.ToInt32(Dt.Rows[0]["UserId"].ToString());
                    user.status = "200";
                    user.message = "success";
                }
                else
                {
                    user.status = "300";
                    user.message = "Not Ok";
                }
            }
            catch (Exception ex)
            {
                user.status = "400";
                user.message = "Error" + ex.Message;

            }
            return user;
        }

    }
}
