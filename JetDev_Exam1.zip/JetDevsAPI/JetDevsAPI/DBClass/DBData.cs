﻿using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace JetDevsAPI.DBClass
{
    public class DBData
    {
        DbCommand objDbCommand;
        string connectionString = "Server=50.62.181.230,1537;Database=JetExam1DB;User id=dev;Password=Manek@tech;Integrated Security=false;";

        public DataTable UserLogin(string Email, string Password)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter("EXEC USP_GetUserLogin '" + Email + "','" + Password + "'", con);
                da.Fill(dt);
                con.Close();

            }
            catch (Exception ex)
            {

                throw;
            }

            return dt;

        }

        public DataTable UserByEmail(string Email)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter("EXEC USP_GetUserByEmail '" + Email + "'", con);
                da.Fill(dt);
                con.Close();

            }
            catch (Exception ex)
            {

                throw;
            }

            return dt;

        }
    }
}
