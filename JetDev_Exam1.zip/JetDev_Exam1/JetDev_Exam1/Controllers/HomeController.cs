﻿using JetDev_Exam1.Model;
using JetDev_Exam1.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Diagnostics;
using System.Text;

namespace JetDev_Exam1.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IConfiguration _configuration;

        HttpClient httpClient = new HttpClient();
        HttpResponseMessage httpResponse;

        const string SessionUserId = "_userId";

        public HomeController(ILogger<HomeController> logger, IConfiguration configuration)
        {
            _logger = logger;
            _configuration = configuration;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost(Name = "UserLogin")]
        public JsonResult UserLogin(UserModel userModel)
        {
            UserModel usrmodel = new UserModel();
            string strBaseUrl = _configuration.GetValue<string>("JetUrl:ApiBaseUrl");

            try
            {
                strBaseUrl = strBaseUrl + "User/UserLogin?Email=" + userModel.Email + "&Password=" + userModel.Password;
                UserModel o = new UserModel();
                StringContent strcontentModel = new StringContent(JsonConvert.SerializeObject(o), Encoding.UTF8, "application/json");

                httpResponse = httpClient.PostAsync(strBaseUrl, strcontentModel).Result;
                if (httpResponse.IsSuccessStatusCode)
                {
                    var content = httpResponse.Content.ReadAsStringAsync().Result;
                    usrmodel = JsonConvert.DeserializeObject<UserModel>(content);
                    if (usrmodel.status == "200")
                    {
                        HttpContext.Session.SetString(SessionUserId, usrmodel.UserId.ToString());

                       
                        return Json(usrmodel);
                    }
                    else if (usrmodel.status == "300")
                    {
                        TempData["ErrorMessage"] = "Invalid User Id OR Password";
                    }
                }
                else
                {
                    TempData["ErrorMessage"] = "Something went wrong";
                }
            }
            catch (Exception)
            {

                throw;
            }
            return Json(TempData["ErrorMessage"]);
        }

        public IActionResult Dashboard()
        {
            return View();
        }

    }
}